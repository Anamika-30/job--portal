package com.jobportal.dto;

public enum ApplicationStatus {
	APPLIED, INTERVIEWING, OFFERED, REJECTED  
}
