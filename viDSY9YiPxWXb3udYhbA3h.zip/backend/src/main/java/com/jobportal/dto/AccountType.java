package com.jobportal.dto;

public enum AccountType {
	APPLICANT, EMPLOYER, ADMIN
}
